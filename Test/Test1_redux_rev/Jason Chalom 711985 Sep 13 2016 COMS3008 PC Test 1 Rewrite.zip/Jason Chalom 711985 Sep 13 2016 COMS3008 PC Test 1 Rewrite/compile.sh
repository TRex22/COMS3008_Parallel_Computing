#!/bin/bash
g++ -fopenmp Question1.4.cpp -o q1.4.out
g++ -fopenmp Question3.cpp -o q3.out
g++ -fopenmp question4.2.cpp -o q4.2.out
g++ -fopenmp question4.3.cpp -o q4.3.out
